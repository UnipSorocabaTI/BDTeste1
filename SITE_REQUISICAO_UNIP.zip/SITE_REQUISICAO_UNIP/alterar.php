﻿
<!DOCTYPE html>

<html lang="en">

<head> 
<script src="js/bootstrap.min.js"></script>  
<link href="css/bootstrap.css" rel="stylesheet">    

</head>
<Body>

<div class="box-body">
        <div id="campos-de-preenchimento">
    <style>
        .red {
            color: #ff0000 !important;
        }
    
        .disabled {
            display: none;
        }
    </style>
<form id = "form_altera_req" method ="POST">
<div id="modal-agendamento-aluno" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">x</button>
                    <h4 class="modal-title" style="text-align: center">Alteração para Agendamento de PROVA SUB</h4>
                </div>
    
                <br>
                
                <div class="row">
    
                    <div class="col-sm-1">
    
                    </div>
                    
                    <div class="col-sm-5">
                        <div class="form-group">
                            <label for="ID">ID:</label>
                            <input type="text" name="ID" class="form-control" id="ID" readonly>
                        </div>
                        <div class="form-group">
                            <label for="CURSO">CURSO:</label>
                            <input type="text" name="CURSO" class="form-control" id="CURSO" readonly >
                        </div>
                        <div class="form-group">
                            <label for="TURMA">TURMA:</label>
                            <input type="text" name="TURMA" class="form-control" id="TURMA" readonly>
                        </div>
                        <div class="form-group">
                            <label for="DISCIPLINA">DISCIPLINA:</label>
                            <input type="text" name="DISCIPLINA" class="form-control" id="DISCIPLINA" readonly >
                        </div>
                    </div>

    
                    <div class="col-sm-5">
                        <div class="form-group">
                            <label for="STATUS">STATUS:</label>
                            <input type="text" name="STATUS" class="form-control" id="STATUS" readonly >
                        </div>
                    
                        <div class="form-group">
                            <label for="TIPOPROVA">TIPO DE PROVA:</label>
                            <select id="TIPOPROVA" name="TIPOPROVA" class="form-control" data-live-search="true" title="Selecione o Tipo de Prova" required>
                                <!--<option value="NP2" >NP2</option>-->
                                <!--<option value="SUB" >SUB</option>-->
                                <option value="EXAME" selected>EXAME</option>
                            </select> 
                        </div>
                        <div class="form-group">
                            <label for="PROFESSOR">PROFESSOR:</label>
                            <input type="text" name="PROFESSOR" class="form-control" id="PROFESSOR" placeholder="Digite o nome do professorª" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="DATAPROVA">DATA DA PROVA:</label>
                            <input type="date" id="DATAPROVA" name="DATAPROVA" class="form-control" oninput="darkmode('data')"data-live-search="true"  min="2022-12-09" max="2022-12-13" required>
                        </div>

                    </div>

                    <div class="row">
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" name="altera_req" value="Atualizar" id="altera_req" style="width: 200px ; height:50px ; margin-left: 35%;"></input>
                        </div>
                    </div>
                    
                    
                    
    
                </div>
    
        </div>
    </div>

    </div>
    </div>
    
</Body>
</html>