﻿<?php
$servername = "192.168.2.19";
$database = "bd_requisicao";
$username = "SRV_BANCO_REQUISICAO";
$password = "";

//Criando a conexão
$conn = mysqli_connect($servername, $username, $password, $database);

//Checando conexão
if (!$conn) {
    die("Falha na conexão: " . mysli_connect_error());
}
//echo "conexão feita";
?>


