<?php
require './bdconnect.php';

    if ($_POST["tipo"] == "cursos") {
        $sql = "SELECT * FROM curso
        ORDER BY nome_curso";
        
        $cursos = mysqli_query($conn, $sql);
        
        while ($row = mysqli_fetch_array($cursos)) {
            $saida[] = array(
                'id' => $row["nome_curso"],
                'nome' => $row["nome_curso"]
            );
        }
        echo json_encode($saida);
    }
    
     else if ($_POST["tipo"] == "turmas") {

        $curso_nome = $_POST["curso_nome"];
        $sql = "SELECT nome_turma
        from turma, curso
        where id_curso = id_curso_turma
        and nome_curso = '{$curso_nome}'
        ORDER BY nome_turma "
                ;
        $turmas = mysqli_query($conn, $sql);

        while ($row = mysqli_fetch_array($turmas)) {
            $saida1[] = array(
                'id' => $row["nome_turma"],

                'nome' => $row["nome_turma"]
            );
        }
        echo json_encode($saida1);
    }

    
    else if ($_POST["tipo"] == "disciplinas"){    

        $curso_nome = $_POST["curso_nome"];
        $turma_nome = $_POST["turma_nome"];

        $sql = "SELECT 

        nome_disciplina   
    
        from turma, disciplina, curso
        where id_turma = id_turma_disc
        and  nome_turma = '$turma_nome'
        AND id_curso = id_curso_turma
        AND id_turma = id_turma_disc
            
        and id_curso_turma = (SELECT id_curso 
        FROM curso 
        WHERE nome_curso = '$curso_nome'
        AND id_curso = id_curso_turma
        AND id_turma = id_turma_disc)";
        
    
        $disciplinas = mysqli_query($conn, $sql);
    
        while ($row = mysqli_fetch_array($disciplinas)) {
            $saida[] = array(
                'id' => $row["nome_disciplina"],
                
                'nome' => $row["nome_disciplina"]
            );
        }
        echo json_encode($saida);
        }
    
     
    
       



?>

