﻿<?php

$host = "192.168.2.19";
$dbname = "bd_requisicao";
$user = "SRV_BANCO_REQUISICAO";
$pass = "";


try{
    //Conexão com a porta
    //$conn = new PDO("mysql:host=$host;dbname=" . $dbname, $user, $pass);
    $conn = mysqli_connect($host, $user, $pass, $dbname);

    //Conexão sem a porta
    //$conn = mysqli_connect ("mysql:host=$host;dbname=" . $dbname, $user, $pass);

    //echo "Conexão com banco de dados realizado com sucesso!";
}  catch(mysqli_connect_error $err){
    echo "Erro: Conexão com banco de dados não realizado com sucesso. Erro gerado " . $err->getMessage();
}

?>