if(window.history.replaceState){
    console.log("EvitarReenvioFormulario")
    window.history.replaceState(null, null, window.Location.href)
}