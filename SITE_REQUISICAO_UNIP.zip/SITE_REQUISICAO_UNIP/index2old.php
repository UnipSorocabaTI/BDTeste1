﻿<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php

include 'bdconnect.php';

if(isset($_POST['submit'])){

    $curso = mysqli_real_escape_string($conn, $_POST['cursos']);
    $turma = mysqli_real_escape_string($conn, $_POST['turmas']);
    $disciplina = mysqli_real_escape_string($conn, $_POST['disciplinas']);
    $periodo = mysqli_real_escape_string($conn,  $_POST['Periodo']);
    $tipo_prova = mysqli_real_escape_string($conn, $_POST['TipodeProva']);
    $data_prova = mysqli_real_escape_string($conn, $_POST['data_prova']);
    $coord = mysqli_real_escape_string($conn, $_POST['coord']);
    $professor = mysqli_real_escape_string($conn, $_POST['professor']);
    $agora = date('y-m-d');
 
    $count_linhas_requisicao = mysqli_query($conn, "SELECT
    bd_requisicao.requisicao.id_requisicao
    FROM bd_requisicao.requisicao
    LEFT JOIN bd_requisicao.curso ON (bd_requisicao.requisicao.id_curso_requisicao = bd_requisicao.curso.id_curso)

    WHERE bd_requisicao.requisicao.id_curso_requisicao = (SELECT bd_requisicao.curso.id_curso 
    FROM bd_requisicao.curso 
    WHERE bd_requisicao.curso.nome_curso = '$curso')
    
    AND bd_requisicao.requisicao.id_turma_requisicao = (SELECT bd_requisicao.turma.id_turma 
    FROM bd_requisicao.disciplina, bd_requisicao.turma, bd_requisicao.curso
    WHERE bd_requisicao.disciplina.nome_disciplina = '$disciplina'
    AND bd_requisicao.curso.nome_curso = '$curso'
    AND bd_requisicao.turma.nome_turma = '$turma'
    AND bd_requisicao.curso.id_curso = bd_requisicao.turma.id_curso_turma
    AND bd_requisicao.turma.id_turma = bd_requisicao.disciplina.id_turma_disc)

    AND bd_requisicao.requisicao.id_disc_requisicao = (SELECT bd_requisicao.disciplina.id_disciplina 
    FROM bd_requisicao.disciplina, bd_requisicao.turma, bd_requisicao.curso
    WHERE bd_requisicao.disciplina.nome_disciplina = '$disciplina'
    AND bd_requisicao.curso.nome_curso = '$curso'
    AND bd_requisicao.turma.nome_turma = '$turma'
    AND bd_requisicao.curso.id_curso = bd_requisicao.turma.id_curso_turma
    AND bd_requisicao.turma.id_turma = bd_requisicao.disciplina.id_turma_disc)")

    or die('query failed');

    $contador_linhas_requisicao = mysqli_num_rows($count_linhas_requisicao);


// Esta variável record count é igual ao Mysqli_num_rows(string de consulta)
    if($contador_linhas_requisicao < 1 ){

        $insert = mysqli_query($conn, "INSERT INTO `requisicao`
        (`coordenador_curso`, `nome_professor`, `periodo_curso`, `tipo_prova`, `status_requisicao`, `data_prova`,
         `data_solicitacao`, `id_usuario_requisicao`, `id_curso_requisicao`, `id_turma_requisicao`, `id_disc_requisicao`)
               
               VALUES ('$coord', '$professor', '$periodo', '$tipo_prova', 'PENDENTE', '$data_prova', '$agora', '1',
              
              (SELECT bd_requisicao.curso.id_curso from bd_requisicao.curso where bd_requisicao.curso.nome_curso = '$curso'),
              
    
              (SELECT bd_requisicao.turma.id_turma 
               from bd_requisicao.disciplina, bd_requisicao.turma, bd_requisicao.curso
               where bd_requisicao.disciplina.nome_disciplina = '$disciplina'
                and bd_requisicao.curso.nome_curso = '$curso'
                and bd_requisicao.turma.nome_turma = '$turma'
                and bd_requisicao.curso.id_curso = bd_requisicao.turma.id_curso_turma
                and bd_requisicao.turma.id_turma = bd_requisicao.disciplina.id_turma_disc),
    
              (SELECT bd_requisicao.disciplina.id_disciplina 
               from bd_requisicao.disciplina, bd_requisicao.turma, bd_requisicao.curso
               where bd_requisicao.disciplina.nome_disciplina = '$disciplina'
                and bd_requisicao.curso.nome_curso = '$curso'
                and bd_requisicao.turma.nome_turma = '$turma'
                and bd_requisicao.curso.id_curso = bd_requisicao.turma.id_curso_turma
                and bd_requisicao.turma.id_turma = bd_requisicao.disciplina.id_turma_disc))") 
    
              or die('query failed');
    
              
             if($insert){     
    
                ?>
    
                <script language="JavaScript">


                    swal({
                      title: "Sucesso!",
                      text: "Requisição salva!",
                      icon: "success",
                      button: "Ok!",
                    });

                    //alert("Salvo com sucesso!");
    
                var paginaHome2 = 1;
              
                </script>
                            
               <?php
    
            
             }

             else{
                $message = 'O registro falhou!';
             }

    }

    else{
        ?>
    
        <script language="JavaScript">

           // alert("Requisição para esta prova já realizada!\nVerifique na consulta de requisições feitas para confirmar.");
           swal({
  title: "Atenção!",
  text: "Requisição para esta prova já foi realizada!",
  icon: "warning",
  button: "Ok!",
});
        var paginaHome2 = 1;
      

        </script>
                    
       <?php

    }

    
}
?>

<!DOCTYPE html>
  <!-- Coding by CodingLab | www.codinglabweb.com -->
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="style2.css">
       <title></title>
        <script src="js/jquery.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap-select.min.css">
        <script src="js/bootstrap-select.min.js"></script>
        <link rel="stylesheet" href="popup.css">
        <script src="notify.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      

    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    
    <!--<title>Dashboard Sidebar Menu</title>--> 

      <script>
    
            $(document).ready(function () {
  
                $('select').selectpicker();
               
                carrega_dados('cursos');
                
                $('[type="date"]').on("keydown", function() {
                event.preventDefault();
                return false;
                });

                function carrega_dados(tipo, curso_nome = '', turma_nome = '', disciplina_nome = ''){
                    $.ajax({
                        url: "carrega_dados.php",
                        method: "POST",
                        data: {tipo: tipo, curso_nome: curso_nome, turma_nome: turma_nome, disciplina_nome: disciplina_nome}, dataType: "json", success: function (data)
                        {

                            var html = '';
                            for (var count = 0; count < data.length; count++){
                                
                                html += '<option value="' + data[count].id + '">' + data[count].nome + '</option>';
                               
                            }
                          
                            if (tipo == 'cursos'){

                                $('#cursos').html(html);
                                $('#cursos').selectpicker('refresh');
                                $('#turmas').val('');

                                $(document).on('change', '#cursos',   function () {
                                    
                                carrega_dados('turmas', $('#cursos').val(),'','');
                                $('#turmas').html('');
                                
                                $('#turmas').selectpicker('refresh');
                                $('#disciplinas').html('');
                                $('#disciplinas').selectpicker('refresh');
                                mysqli_close($conn);
                                });

                            } 
                           
                            else if (tipo == 'turmas'){

                                $('#turmas').html(html);
                                $('#turmas').selectpicker('refresh');
                                $('#disciplinas').val('');
                                $(document).on('change', '#turmas',  function () {
                                    
                                carrega_dados('disciplinas',$('#cursos').val(),$('#turmas').val());
                                        
                                $('#disciplinas').html('');
                                
                                $('#disciplinas').selectpicker('refresh');
                                mysqli_close($conn);
                               
                                });


                            } 

                            else if (tipo == 'disciplinas'){
                                $('#disciplinas').html(html);
                                $('#disciplinas').selectpicker('refresh');
                                $(document).on('change', '#turmas',  function () {

                                carrega_dados('disciplinas',$('#cursos').val(),$('#turmas').val(),$('#disciplina').val());
                                mysqli_close($conn);
                                });
                                

                            } 

                            //<title>Carrega o curso das requisicoes já realizadas</title>--> 
                            if (tipo == 'cursos'){

                                $('#busca').html(html);
                                $('#busca').selectpicker('refresh');


                                $(document).on('change', '#busca',   function () {
                                
                                    mysqli_close($conn);
                                
                                });

                            } 

                           
                           

                        }

                    })

                }

            });


            
            //-----------------------------//

        </script>

</head>

<body>


    <nav class="sidebar close2">
        <header>
            <div class="image-text">
                <div class="text logo-text">
                   <img src="https://unip.br/assets/img/logo/logo-unip.svg" alt="logounip">
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

                <li class="search-box">
                    <i class='bx bx-search icon'></i>
                    <input type="text" placeholder="Pesquisar..">
                </li>

                <ul class="menu-links">
                    <li class="nav-link" onclick="abrirAVA('inicio')">
                        <a href="#" id="layout-blue">
                            <i class='bx bx-home icon'></i>
                            <span class="text nav-text">Início</span>
                        </a>
                    </li>


                    


                    <li class="nav-link" onclick="abrirAVA('user_AVA')">

     

                        <a href="#" id="layout-blue">
                            <i class='bx bx-calendar-check icon' ></i>
                            <span class="text nav-text">Requisições Feitas</span>
                        </a>
                    </li>

                 <li class="nav-link" > <!-- onclick="abrirAVA('user_AVA')" -->
                        <a href="#" id="disable">
                            <i class='bx bx-user icon' ></i>
                            <span class="text nav-text">Usuário</span>
                        </a>
                    </li> 

                    <!--  <li class="nav-link" >
                        <a href="#" id="layout-blue">
                            <i class='bx bx-plus-circle icon' ></i>
                            <span class="text nav-text">Nova Requisição</span>
                        </a>
                    </li> -->

                  

                   <li class="nav-link" > <!-- onclick="abrirAVA('anexo_AVA') -->
                        <a href="#" id="disable">
                            <i class='bx bx-export icon'></i>
                            <span class="text nav-text">Provas Anexadas</span>
                        </a>
                    </li>

                     <li class="nav-link"  >
                        <a href="#" id="disable">
                            <i class='bx bx-history icon' ></i>
                            <span class="text nav-text">Status</span>
                        </a>
                    </li>
                </ul>
            </div>

            <script src="evitar_reenvio.js"></script>
            <div class="bottom-content">
               
                <li class="mode">
                    <div class="sun-moon">
                        <i class='bx bx-moon icon moon'></i>
                        <i class='bx bx-sun icon sun'></i>
                    </div>
                    <span class="mode-text text">Modo Noturno</span>

                    <div class="toggle-switch">
                        <span class="switch"></span>
                    </div>
                </li>
                
            </div>
        </div>

    </nav>


    <section class="home">
        
        <div class="teste-de-body">

             <div id="inicio" class="form-tester" style="display: flex;flex-direction: column;" >
             <div class="row" id="title_req"  style="display: flex; justify-content: center;">
                <h1>SELECIONE O TIPO DE PROVA</h1>
            </div>
            <div class="row"> 
                <div class="col-md-6" style="display: flex; justify-content:center; align-items: center">
                <div class="card" style="box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.2);min-height:90%;width: 40rem; border: solid 1px rgba(0, 0, 0, 0.123); padding: 0px; margin: 5px; overflow: hidden; overflow-x: hidden; border-radius: 5px;">
                    <img src="pexels-andy-barbour-6684285.jpg"  style="width: 100%;max-height: 65%;" class="card-img-top" alt="...">
                    <div class="card-body"  style="padding: 20px;max-height: 35%">
                      <h5 class="card-title" style="font-weight: bold;">Fazer requisição AVA</h5>
                      <p class="card-text">Clique aqui para preencher a requisição de prova do tipo AVA que será aplicada presencialmente.<br><br><br><br></p>
                      <a href="#" class="btn btn-primary"style="display: flex; align-items: center; justify-content: center; width: 12em;font-weight: bold; background-color: #07366a" onclick="abrirAVA('new_req')">Fazer requisição AVA</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6" style="display: flex; justify-content:center; align-items: center">
                <div class="card" style="box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.2);min-height:90%;width: 40rem; border: solid 1px rgba(0, 0, 0, 0.123); padding: 0px; margin: 5px; overflow: hidden; overflow-x: hidden; border-radius: 5px;">
                    <img src="PV.jpg"  style="width: 100%;max-height: 65%; -webkit-filter:grayscale(100%);filter: grayscale(100%);filter:gray;" class="card-img-top" alt="...">
                    <div class="card-body"  style="padding: 20px;min-height: 35%">
                      <h5 class="card-title "style="font-weight: bold;">Arquivo / Prova Comum <font color="red">&emsp;EM BREVE</font></h5>
                      <p class="card-text" >Clique aqui para anexar um arquivo(.pdf) da prova do tipo Comum que será aplicada em sala de aula.<br><br><br></p>
                      <a href="#" class="btn btn-primary" style="display: flex; align-items: center; justify-content: center; width: 12em;font-weight: bold ; background-color: #07366a" disabled>Enviar prova comum</a>
                    </div>
                </div>
            </div>

            </div>
            
            </div>

    
        <form id = "form_req" method ="POST">
         <!--aqui abre o formulario-->

                  
            <div id="user_AVA" class="form-tester"> 

                       <div class="row"> <p align = "center" class="card-text" style="font-weight: bold;"> 
                       <br><font size="5"> REQUISIÇÕES REALIZADAS</font><br><br></p>

                
                       <div class="row-md-12" id="row_btn">
                      
                       <div class="row" style="display:flex; align-items: center; justify-content:center">
                <div class="col-md-4">
                <div class="form-group">
                        <select name="busca" id="busca" class="form-control input-lg" data-live-search="true" title="Selecione o Curso" required>

                        </select>
                    </div>
                </div>

                <div class="col-md-3" style="display:flex; align-items: center; justify-content:center">
                            
                            <div class="form-group">
                            <input type="submit" class="btn btn-success" name="btn_busca" value="Buscar Requisição" id="btn_busca" style="width: 200px ; height:50px"></input>
                            </div> 
                        </div>

            </div>
            <div class="row" id="title_req" style="display:block; align-items: center; justify-content:center">
                    <li class="nav-link" > <!-- onclick="abrirAVA('user_AVA')" -->



                <div class="col-md-12" style="display: flex; justify-content:center; align-items:baseline">  



                <div class="card" style="box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.2);min-height:100%;width: 100%; border: solid 1px rgba(0, 0, 0, 0.123); padding: 10px; margin: 10px; overflow: hidden; overflow-x: hidden; border-radius: 5px;">
              
                    <div class="card-body" style="padding: 1px;max-height: 35%">
                    
                   <?php


include_once 'conexao.php';


if (isset($_POST['btn_busca']))
{

    //$buscaRequisicaoFeita = 'BIOMEDICINA';
    $buscaRequisicaoFeita = $_POST['busca'];
    ?>
    <script language="JavaScript">
    
            var paginaHome = 2;
            paginaHome2 = 0;
            </script>
    <?php
   
}

else{

    $buscaRequisicaoFeita = '';
    ?>
    <script language="JavaScript">
    
            paginaHome = 1;
            </script>
    <?php

}


                    if (isset($_SESSION['msg'])) {

                         echo $_SESSION['msg'];
                         unset($_SESSION['msg']);

                           
                        }
                        $count=0;
    
                        $query_usuarios = "SELECT requisicao.nome_professor, curso.nome_curso,turma.nome_turma, disciplina.nome_disciplina, requisicao.tipo_prova, requisicao.status_requisicao, date_format(data_prova,'%d/%m/%Y') data_prova
                        from requisicao, curso, turma, disciplina
                        where requisicao.id_curso_requisicao = curso.id_curso
                        and requisicao.id_turma_requisicao = turma.id_turma
                        and requisicao.id_disc_requisicao = disciplina.id_disciplina
                        and curso.nome_curso = '$buscaRequisicaoFeita'
                        ORDER BY YEAR(data_prova),
                        MONTH(data_prova), DAY(data_prova) ASC";
   
   
                    //$buscaRequisicaoFeita = 'BIOMEDICINA';

                    
                    //order by convert(datetime, date, 103) ASC
                                    
                    /*$query_usuarios = "SELECT requisicao.nome_professor, curso.nome_curso,turma.nome_turma,    disciplina.nome_disciplina, requisicao.tipo_prova,                        requisicao.status_requisicao, date_format(data_prova,'%d/%m/%Y') data_prova
                    from requisicao, curso, turma, disciplina
                    where requisicao.id_curso_requisicao = curso.id_curso
                    and requisicao.id_turma_requisicao = turma.id_turma
                    and requisicao.id_disc_requisicao = disciplina.id_disciplina
                    order by data_prova DESC";*/
                                         
                     //$result_usuarios = $conn->prepare($query_usuarios);
                     //$result_usuarios->execute();

                     $stmt = mysqli_prepare($conn, $query_usuarios);
                     mysqli_stmt_execute($stmt);
 
                     mysqli_stmt_bind_result($stmt, $nome_professor, $nome_curso, $nome_turma, $nome_disciplina, $tipo_prova, $status_requisicao, $data_prova);
 
 
                   
                  
                     
                     
                     ?>

<br>
                    
                     <table class="table"> <tr> 
                   
                     <th>  <?php echo "PROFESSOR: "; ?>
                     </th>
                     <th>  <?php echo "CURSO: "; ?>
                     </th> 
                     <th>  <?php echo "TURMA: "; ?>
                     </th>
                     <th>  <?php echo "DISCIPLINA: "; ?>
                     </th>
                     <th> <?php echo "TIPO PROVA:"; ?>
                     </th>
                     <th> <?php echo "STATUS:"; ?>
                     </th>
                     <th> <?php echo "DATA PROVA:"; ?>
                     </th></tr>  


                     <?php                
                     
                     include_once "conexao.php";


                    // while ($row_usuario = $result_usuarios->fetch(PDO::FETCH_ASSOC)){
                        
                        while(mysqli_stmt_fetch($stmt)){

                            $count+=1;
                        
                        // extract($row_usuario);
                         
                         ?>
                         <tr> 
                          
                          <td>  <?php echo "$nome_professor &nbsp"; ?>
                          </td>
                          <td>  <?php echo "$nome_curso &nbsp"; ?>
                          </td> 
                          <td>  <?php echo "$nome_turma &nbsp"; ?>
                          </td>
                          <td>  <?php echo "$nome_disciplina &nbsp"; ?>
                          </td>
                          <td align = "center"> <?php echo "$tipo_prova &nbsp"; ?>
                          </td>
                          <td> <?php echo "$status_requisicao &nbsp"; ?>
                          </td>
                          <td> <?php echo "$data_prova &nbsp"; ?>
                          </td>
                          <?php 


                     }
                     ?>
                     
                    </tr> </table>

                    <?php

                        echo "Requisições realizadas: $count";

                   ?>



                     
                      
                    </div>
                </div>
            </div>

                       
                        </p>
                    </li> 
                </div>

        </div>

        </div>
        </div>
                </form>

        <div id="new_req" class="form-tester"> 
                <div class="row" id="title_req" style="display:flex; align-items:top; justify-content:center"><h1>REQUISIÇÃO DE PROVA AVA</h1>
                    <li class="nav-link" > <!-- onclick="abrirAVA('user_AVA')" -->
                        <a href="#" id="disable">
                          
                        </a>
                    </li> 
                </div>
<form id="myform" method="POST">

            <div class="row">
                <div class="col-md-12">
                <div class="form-group">
                        <label>SELECIONE UM CURSO:</label>
                        <select name="cursos" id="cursos" class="form-control input-lg" data-live-search="true" title="Selecione o Curso" required>
                        </select>
                    </div>
                </div>
            </div>
             <div class="row">
                  <div class="col-md-12">
                 <div class="form-group">
                        <label>SELECIONE UMA TURMA:</label>
                        <select name="turmas" id="turmas" class="form-control input-lg" data-live-search="true" title="Selecione a Turma" required></select>
                    </div>
                    </div>
             </div>
              <div class="row">
                 <div class="col-md-12">
                   <div class="form-group">
                        <label>SELECIONE UMA DISCIPLINA:</label>
                        <select name="disciplinas" id="disciplinas" style="display: none ;" class="form-control input-lg" data-live-search="true" title="Selecione a Disciplina" required></select>
                    </div>
                    </div>
              </div>
               <div class="row">
                 <div class="col-md-6">
                    <div class="form-group">
                            <label for="Coordenador">COORDENADOR:</label>
                            <input type="text" id="box" name="coord" class="form-control input-lg" data-live-search="true" placeholder="Digite o nome do coordenador" oninput="darkmode('coord')"  required>
                            
                            <script>
                                
                                document.getElementById('box').addEventListener('keyup', (ev) => {
                                const input = ev.target;
                                input.value = input.value.toUpperCase();
                            });
                            </script>
                    </div>
                    </div>
                    <script>
                        
                    </script>
                    <div class="col-md-6">
                    <div class="form-group">
                            <label for="Coordenador">PROFESSOR:</label>
                            <input type="text" id="box2" name="professor" class="form-control input-lg"  oninput="darkmode('teacher')" data-live-search="true" placeholder="Digite o nome do professor" required>
                            <script>
                                document.getElementById('box2').addEventListener('keyup', (ev) => {
                                const input = ev.target;
                                input.value = input.value.toUpperCase();
                     
                            });
                            </script>
                    </div>
                        <script>
                            function darkmode(teacher, qtd_prova, coord, data){

                                if (document.getElementById("box2").value.length  != ''){

                                document.getElementById('box2').style.background= 'white'
                            }
                                else{
                                 document.getElementById('box2').style.background= ''
                                }
                                     
                                if (document.getElementById("box").value.length != ''){

                                    document.getElementById('box').style.background= 'white'
                            }
                                else{
                                 document.getElementById('box').style.background= ''
                                }
                                 if (document.getElementById("data_prova").value.length != ''){

                                document.getElementById('data_prova').style.background= 'white'
                            }
                                else{
                                 document.getElementById('data_prova').style.background= ''
                                }

                            }
                        
                        </script>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="Data Prova">DATA DA PROVA:</label>
                                <input type="date" id="data_prova" name="data_prova" class="form-control input-lg" oninput="darkmode('data')"data-live-search="true" min="2022-11-22" max="2022-11-30" required>
                    </div>
                    </div>

                    <div class="col-md-4">
                         <div class="form-group">
                            <label for="Periodo">PERÍODO:</label>
                            <select id="box3" name="Periodo" class="form-control input-lg" data-live-search="true" title="Selecione o Período" required >
                            
                            
                                <option>MANHÃ</option>
                                <option>NOITE</option>
                                 
                            </select>     
                    </div>

                    </div>

<div class="col-md-4">
                     <div class="form-group">
                            <label for="Tipo de Prova">TIPO DE PROVA:</label>
                            <select id="box4" name="TipodeProva" class="form-control input-lg" data-live-search="true" title="Selecione o Tipo de Prova" required>
                                <option value="SUB" selected>SUB</option>
                                <!--<option value="SUB">SUB</option>-->
                                <!--<option value="EXAME">EXAME</option>-->
                            </select> 
                    </div>

</div>
                    

                    <div class="row-md-1" id="row_btn">
                        <div class="col-md-12">
                            
                            <div class="form-group">
                            <input type="submit" class="btn btn-success" name="submit" value="Enviar Requisição" id="btn_succes" style="width: 200px ; height:50px"></input>
                            </div> 
                        </div>
                        
                        <script>
                            $("#btn_succes").click(function () {
                                
                                var curso = $("#cursos").val();
                                var turma = $("#turmas").val();
                                var disciplina = $("#disciplinas").val();
                                var coordenador = $("#box").val();
                                var data = $("#data_prova").val();
                                var periodo = $("#box3").val();
                                var tipoProva = $("#box4").val();

                    
                                if (curso == ''  || turma == ''  || disciplina== ''  || coordenador == ''  || data == ''  || periodo == ''  || tipoProva == ''  || numeroProva == '') {
                                    swal({
                                        title: "Preencha todos os campos!",
                                        text: "Verifique se todos os campos estão preenchidos",
                                        icon: "warning",
                                        button: "OK",
                                    }
                                    )
                                }

                               
                            });
                        </script>


                    </div>
            </div>

        </div>
           
                     <div id="upload_AVA" class="form-tester">
                        
                    </div>

                    <div  id="anexo_AVA" class="form-tester">
                        <h1>Teste de Anexo</h1>
                    </div>
   </form>   
   


<!-- Modal -->

    </section>

<script>
    const body = document.querySelector('body'),
      sidebar = body.querySelector('nav'),
      toggle = body.querySelector(".toggle"),
      searchBtn = body.querySelector(".search-box"),
      modeSwitch = body.querySelector(".toggle-switch"),
      modeText = body.querySelector(".mode-text");

toggle.addEventListener("click" , () =>{
    sidebar.classList.toggle("close2");
})

searchBtn.addEventListener("click" , () =>{
    sidebar.classList.remove("close2");
})

modeSwitch.addEventListener("click" , () =>{
    body.classList.toggle("dark");
    
    if(body.classList.contains("dark")){
        modeText.innerText = "Modo Claro";
    }else{
        modeText.innerText = "Modo Escuro";
        
    }
});
    </script>






    <script>

function abrirAVA(idTab) {

if (idTab == 'new_req' ) {

    var conteudos = document.getElementsByClassName('form-tester');

    for (var i = 0; i < conteudos.length;  i++) {
       conteudos[i].style.display = 'none';
    }

    document.getElementById(idTab).style.display = 'block';

        navigation.classList.toggle('active');
        main.classList.toggle('active');
    

    i = null;
    j = null;


    

}
else if (idTab == 'upload_AVA' ) { 

    var conteudos = document.getElementsByClassName('form-tester');

    for (var i = 0; i < conteudos.length;  i++)
     {
       conteudos[i].style.display = 'none'; 
       }
    
    document.getElementById(idTab).style.display = 'block';

    i = null;
    
}
else if (idTab == 'user_AVA' ) { 

   
    
    var conteudos = document.getElementsByClassName('form-tester');

    for (var i = 0; i < conteudos.length;  i++)
     {
       conteudos[i].style.display = 'none'; 
       }
    
    document.getElementById(idTab).style.display = 'block';

    i = null;
    

    

}
else if (idTab == 'inicio' ) { 

var conteudos = document.getElementsByClassName('form-tester');

for (var i = 0; i < conteudos.length;  i++)
 {
   conteudos[i].style.display = 'none'; 
   }

document.getElementById(idTab).style.display = 'flex';
document.getElementsByClassName('teste-de-body').style.border = 'none';

i = null;
}

else if (idTab == 'anexo_AVA' ) { 

    var conteudos = document.getElementsByClassName('form-tester');

    for (var i = 0; i < conteudos.length;  i++)
     {
       conteudos[i].style.display = 'none'; 
       }
    
    document.getElementById(idTab).style.display = 'block';

    i = null;
}}
    </script>



      <script language="JavaScript">
       //Favor não mexer nas alteraçãoes dos ifs abaixo, pois pode modificar a apresentação nas requisições realizadas
       //e no momento que a pessoa finaliza/salva uma requisicao 06/10/22



            if (paginaHome2 == 1){

                abrirAVA('new_req');

            }


            else if (paginaHome == 2){

            abrirAVA('user_AVA');

            }
           
           
            </script>


</body>

<script type="text/javascript" src="evitar_reenvio.js"></script>
</html>
