$(function(){
$('#mytable').DataTable({
                    "language": {
                    "emptyTable": "Sem dados dispon�veis na tabela",
                    "info":           "Mostrando _START_ de _END_ no total de _TOTAL_ registros",
                    "infoEmpty":      "Mostrando 0 de 0 no total de 0 registros",
                    "infoFiltered":   "(filtrado do total de _MAX_ registros)",
                    "infoPostFix":    "",
                    "thousands":      ",",
                    "lengthMenu":     "Mostrar _MENU_ registros",
                    "loadingRecords": "Carregando...",
                    "processing":     "",
                    "search":         "Pesquisar:",
                    "zeroRecords":    "Nenhum registros encontrado!",
                    "paginate": {
                        "first":      "Primeiro",
                        "last":       "Ultimo",
                        "next":       "Proximo",
                        "previous":   "Anterior"
                    },
                    },    
                    lengthMenu: [
                        [10, 25, 50, -1],
                        [10, 25, 50, 'Todos'],
                    ],
                });
});