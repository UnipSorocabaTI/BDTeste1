function showUser() 
{
                var str=load_new_content2();
		/*var r=load_new_content();*/
		
		
            /*if (str=="") {
                document.getElementById("txtHint").innerHTML="";
                return;
            }*/
                var xmlhttp=new XMLHttpRequest();
                xmlhttp.onreadystatechange=function() {
		document.getElementById("txtHint").innerHTML='<div style="text-align: center; width:100%; margin-top:5%; color:#777; font-size:1em;"><i class="fa fa-spinner fa-spin fa-3x fa-fw" aria-hidden="true" style="margin: 0 auto; width: 100%;"></i><p class="texto" style="margin: 0 auto; width: 100%; display: inline-block; font-size:1.3em;">Buscando registros...</p></div>';
                    if (this.readyState==4 && this.status==200) {
                        document.getElementById("txtHint").innerHTML=this.responseText;
			$('#mytable').dataTable({
                    		"language": {
                    		"emptyTable": "Sem dados dispon�veis na tabela",
                    		"info":           "Mostrando _START_ de _END_ no total de _TOTAL_ registros",
                    		"infoEmpty":      "Mostrando 0 de 0 no total de 0 registros",
                    		"infoFiltered":   "(filtrado do total de _MAX_ registros)",
                    		"infoPostFix":    "",
                    		"thousands":      ",",
                    		"lengthMenu":     "Mostrar _MENU_ registros",
                    		"loadingRecords": "Carregando...",
                    		"processing":     "",
                    		"search":         "Pesquisar:",
                    		"zeroRecords":    "Nenhum registro encontrado!",
                    		"paginate": {
                        	"first":      "Primeiro",
                        	"last":       "Ultimo",
                        	"next":       "Proximo",
                        	"previous":   "Anterior"
                    		},
                    		},    
                    		lengthMenu: [
                        	[10, 25, 50, -1],
                        	[10, 25, 50, 'Todos'],
                    		],
                	});
                    }
                    }
                /*xmlhttp.open("GET","getuser.php?q="+encodeURIComponent(str)+ "&r=" + encodeURIComponent(r),true);*/
		xmlhttp.open("GET","getuser.php?q="+encodeURIComponent(str),true);
                xmlhttp.send();		
}
