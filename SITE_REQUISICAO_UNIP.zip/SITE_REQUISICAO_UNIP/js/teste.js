function tablle() {
    $('#mytable').DataTable({});
}

$('#mytable').ajaxSuccess(function(){
                    $(this).dataTable();
                })