function load_new_content2(){
                var buscavalue=$("#busca option:selected").val();
		$("#busca").val('');
   		$("#busca").selectpicker('refresh');
                return buscavalue;}
                
function load_new_content(){
                var selected_option_value=$("#ordem option:selected").val(); //get the value of the current selected option.
                $("#ordem").val('');
   		$("#ordem").selectpicker('refresh');
                return selected_option_value;
               /* $.post("script_that_receives_value.php", {option_value: selected_option_value},
                    function(data){ //this will be executed once the `script_that_receives_value.php` ends its execution, `data` contains everything said script echoed.
                        $($rt).html(data);
                        alert(data); //just to see what it returns
                        
                    }
                );*/
            }