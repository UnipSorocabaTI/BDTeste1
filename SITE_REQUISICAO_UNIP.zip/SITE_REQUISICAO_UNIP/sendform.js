
$(function(){
  $('.form').submit(function(event){
      event.preventDefault();
      var formDados = $('.form').serialize();

      $.ajax({
          url:'envia.php',
          type:'POST',
          data:formDados,
          cache:false,
          processData:false,
          success:function(data){
              alert('Cadastrado com sucesso!');
          },
          dataType:'html'
      });
      return false;
  });
});