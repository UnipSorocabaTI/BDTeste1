<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php

include 'bdconnect.php';

if(isset($_POST['altera_req'])){

   
    $curso = mysqli_real_escape_string($conn, $_POST['CURSO']);
    $turma = mysqli_real_escape_string($conn, $_POST['TURMA']);
    $disciplina = mysqli_real_escape_string($conn, $_POST['DISCIPLINA']);
    //$periodo = mysqli_real_escape_string($conn,  $_POST['Periodo']);
    $tipo_prova = mysqli_real_escape_string($conn, $_POST['TIPOPROVA']);
    $data_prova = mysqli_real_escape_string($conn, $_POST['DATAPROVA']);
    //$coord = mysqli_real_escape_string($conn, $_POST['coord']);
    $professor = mysqli_real_escape_string($conn, $_POST['PROFESSOR']);
    $VAR = mysqli_real_escape_string($conn, $_POST['ID']);
    $agora = date('y-m-d');
    
    if($tipo_prova =="NP2"){
    ?>
       <script language="JavaScript">
            
            swal({
                      title: "Atenção!",
                      text: "Requisição já alterada, entre em contato com o setor de Informática!",
                      icon: "warning",
                      button: "Ok!",
                    });
       </script>
    <?php
    }

    else{
    $update = mysqli_query($conn, "UPDATE requisicao SET
                 nome_professor='$professor', tipo_prova='$tipo_prova', 
                 data_prova='$data_prova'
                 WHERE requisicao.id_requisicao = '$VAR'")
           
                                       
          or die('query failed');
          
         if($update){     
            mysqli_close($conn);
            ?>

            <script language="JavaScript">
             
             swal({
                      title: "Sucesso!",
                      text: "Requisição atualizada!",
                      icon: "success",
                      button: "Ok!",
                    });
                
                var paginaHome = 0;
            paginaHome2 = 0;
          
            </script>
                        
           <?php

        
         }
         else{
            $message = 'O registro não foi alterado!';
         }
    }
}
?>
