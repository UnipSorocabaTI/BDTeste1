
<!DOCTYPE html>
<html>
<head>
<!--<style>
table {
  width: 100%;
  border-collapse: collapse;
}

table, td, th {
  border: 1px solid black;
  padding: 5px;
}

th {text-align: left;}
</style>-->
</head>
<body>

<?php
include_once 'connectBD.php';

$buscaRequisicaoFeita = $_GET['q'];
$order = $_GET['r'];

//mysqli_select_db($con,"ajax_demo");




if(isset($buscaRequisicaoFeita))
{


    switch ($order) {
        case 'PROFESSOR':
            $order ='requisicao.nome_professor';
            break;
        case 'CURSO':
            $order ='curso.nome_curso';
            break;
        case 'TURMA':
            $order ='turma.nome_turma';
            break;
        case 'DISCIPLINA':
            $order ='disciplina.nome_disciplina';
            break;
        case 'PROVA':
            $order ='requisicao.tipo_prova';
            break;
        case 'DATA':
            $order ='data_prova';
            break;
        default:
            $order ='requisicao.status_requisicao';
            break;
    }

    if ($buscaRequisicaoFeita == '')
    {
        $h = 2;
    }
    else
    {
        $h = 3;
    }    
          
}

else 
{
    $h=null; 
    $order = 'requisicao.status_requisicao';
}
    ?>

<?php


                    if (isset($_SESSION['msg'])) {

                         echo $_SESSION['msg'];
                         unset($_SESSION['msg']);

                           
                        }
                    $count=0;
                    if ($h == 3) 
                    {      
                      $query_usuarios = "SELECT requisicao.id_requisicao, UPPER(requisicao.nome_professor) AS nome_professor , curso.nome_curso,turma.nome_turma, disciplina.nome_disciplina, requisicao.tipo_prova, requisicao.status_requisicao, date_format(data_prova,'%d/%m/%Y') data_prova
                      from requisicao, curso, turma, disciplina
                      where requisicao.id_curso_requisicao = curso.id_curso
                      and requisicao.id_turma_requisicao = turma.id_turma
                      and requisicao.id_disc_requisicao = disciplina.id_disciplina
                      and curso.nome_curso = '$buscaRequisicaoFeita'
                      ORDER BY $order ASC, requisicao.status_requisicao, data_prova";
                      $stmt = mysqli_query($conn, $query_usuarios);
                    }

                    else 
                    {
                    //order by convert(datetime, date, 103) ASC
                      $query_usuarios = "SELECT requisicao.id_requisicao, UPPER(requisicao.nome_professor) AS nome_professor , curso.nome_curso,turma.nome_turma, disciplina.nome_disciplina, requisicao.tipo_prova, requisicao.status_requisicao, date_format(data_prova,'%d/%m/%Y') data_prova
                      from requisicao, curso, turma, disciplina
                      where requisicao.id_curso_requisicao = curso.id_curso
                      and requisicao.id_turma_requisicao = turma.id_turma
                      and requisicao.id_disc_requisicao = disciplina.id_disciplina
                      /*and DAY(data_prova) = '08'
                      and MONTH(data_prova) = '11'*/
                      ORDER BY $order ASC,requisicao.status_requisicao,data_prova";
                      $stmt = mysqli_query($conn, $query_usuarios);
                    }
                  //mysqli_stmt_bind_result($stmt, $nome_professor, $nome_curso, $nome_turma, $nome_disciplina, $tipo_prova, $status_requisicao, $data_prova);
?>
<br>
                     <table class="table"> <tr> 
                      
                     <th>  <?php echo "ID:  "; ?>
                     </th>
                     <th>  <?php echo "<a >PROFESSOR:  </a>"; ?>
                     </th>
                     <th >  <?php echo "CURSO: "; ?>
                     </th> 
                     <th>  <?php echo "TURMA: "; ?>
                     </th>
                     <th>  <?php echo "DISCIPLINA: "; ?>
                     </th>
                     <th> <?php echo "TIPO PROVA:"; ?>
                     </th>
                     <th> <?php echo "STATUS:"; ?>
                     </th>
                     <th> <?php echo "DATA PROVA:"; ?>
                     </th></tr>

                  
                     <?php                


                   
                      while( $row = mysqli_fetch_array($stmt)) {
                      // while(mysqli_stmt_fetch($stmt)){

                        $count+=1;
  
                         ?>
                         <tr>  
                         <td>  <?php echo $row['id_requisicao'], " &nbsp"; ?>
                          </td>
                          <td>  <?php echo $row['nome_professor'], " &nbsp"; ?>
                          </td>
                          <td>  <?php echo $row['nome_curso'], "&nbsp"; ?>
                          </td> 
                          <td>  <?php echo $row['nome_turma'], "&nbsp";?>
                          </td>
                          <td>  <?php echo $row['nome_disciplina'], "&nbsp";?>
                          </td>
                          <td align = "center"> <?php echo $row['tipo_prova'], "&nbsp"; ?>
                          </td>
                          <td> <?php echo $row['status_requisicao'], "&nbsp"; ?>
                          </td>
                          <td> <?php echo $row['data_prova'], "&nbsp"; ?>
                          </td>
                          <?php 
                     }
                     ?>
                     
                    </tr> </table>

                    <?php
                        echo "Requisições realizadas. $count"

                   ?>
<?php                  
mysqli_close($conn);
?>
</body>
</html> 