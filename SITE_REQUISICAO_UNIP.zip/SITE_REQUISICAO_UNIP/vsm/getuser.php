
<!DOCTYPE html>
<html>

<head>
<script type="text/javascript" language="javascript" src="js/jquery-3.5.1.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php include 'alterar.php'; ?>

</head>
<body>


<?php
include_once 'bdconnect.php';

$buscaRequisicaoFeita = $_GET['q'];

if(isset($buscaRequisicaoFeita))
{

    if ($buscaRequisicaoFeita == '')
    {
        $h = 2;
    }
    else
    {
        $h = 3;
    }    
          
}

else 
{
    $h=null;
}
    ?>

<?php


                    if (isset($_SESSION['msg'])) {

                         echo $_SESSION['msg'];
                         unset($_SESSION['msg']);

                           
                        }
                    if ($h == 3) 
                    {    
                      $query_usuarios = "SELECT requisicao.id_requisicao, requisicao.nome_professor AS nome_professor , curso.nome_curso,turma.nome_turma, disciplina.nome_disciplina, requisicao.tipo_prova, requisicao.status_requisicao, date_format(data_prova,'%d/%m/%Y') data_prova
                      from requisicao, curso, turma, disciplina
                      where requisicao.id_curso_requisicao = curso.id_curso
                      and requisicao.id_turma_requisicao = turma.id_turma
                      and requisicao.id_disc_requisicao = disciplina.id_disciplina
                      and curso.nome_curso = '$buscaRequisicaoFeita'
                      ORDER BY requisicao.status_requisicao,data_prova";
                      $stmt = mysqli_prepare($conn, $query_usuarios);
                    }

                    else 
                    {
                    //order by convert(datetime, date, 103) ASC
                      $query_usuarios = "SELECT requisicao.id_requisicao, requisicao.nome_professor AS nome_professor , curso.nome_curso,turma.nome_turma, disciplina.nome_disciplina, requisicao.tipo_prova, requisicao.status_requisicao, date_format(data_prova,'%d/%m/%Y') data_prova
                      from requisicao, curso, turma, disciplina
                      where requisicao.id_curso_requisicao = curso.id_curso
                      and requisicao.id_turma_requisicao = turma.id_turma
                      and requisicao.id_disc_requisicao = disciplina.id_disciplina
                      ORDER BY requisicao.status_requisicao,data_prova";
                      $stmt = mysqli_prepare($conn, $query_usuarios);
                    }
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_bind_result($stmt,$id_requisicao,$nome_professor, $nome_curso, $nome_turma, $nome_disciplina, $tipo_prova, $status_requisicao, $data_prova);
?>

                <table id="mytable" class="display" >
                    <thead>
                     <tr>
                     <th>  <?php echo "ID:  "; ?>
                     </th>
                     <th>  <?php echo "PROFESSOR: "; ?>
                     </th>
                     <th>  <?php echo "CURSO: "; ?>
                     </th> 
                     <th>  <?php echo "TURMA: "; ?>
                     </th>
                     <th>  <?php echo "DISCIPLINA: "; ?>
                     </th>
                     <th align="center"> <?php echo "TIPO PROVA: "; ?>
                     </th>
                     <th> <?php echo "STATUS: "; ?>
                     </th>
                     <th> <?php echo "DATA PROVA: "; ?>
                     </th>
                     <th class="row-edit dt-center sorting_disabled" rowspan="1" colspan="1" style="width: 13px;" aria-label=""></th>
                     </tr>
                    </thead>
                    

                    <tbody id="mytbody">
                    <?php                
                    
                    while(mysqli_stmt_fetch($stmt)){
  
                    ?>
                    
                        <tr>  
                            <td>  <?php echo "$id_requisicao"; ?>
                            </td>
                            <td>  <?php echo "$nome_professor"; ?>
                            </td>
                            <td>  <?php echo "$nome_curso"; ?>
                            </td> 
                            <td>  <?php echo "$nome_turma";?>
                            </td>
                            <td>  <?php echo "$nome_disciplina";?>
                            </td>
                            <td align="center"> <?php echo "$tipo_prova"; ?>
                            </td>
                            <td> <?php echo "$status_requisicao"; ?>
                            </td>
                            <td> <?php echo "$data_prova"; ?>
                            </td>
                            <td class="  row-edit dt-center"><a data-toggle="modal" onclick="roww($(this).closest('tr'))" data-target="#modal-agendamento-aluno"><i class="fa fa-pencil"></i></a>
                            </td>
                        </tr>
                    
                    <?php 
                    }
                    ?>   
                    </tbody>
                </table>
<?php
$stmt->close();           
mysqli_close($conn);
?>

</body>

</html> 