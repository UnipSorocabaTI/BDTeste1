<?php

include 'bdconnect.php';
//ssssalert("Salvo com sucesso!");
if(isset($_POST['altera_req'])){

   
    $curso = mysqli_real_escape_string($conn, $_POST['CURSO']);
    $turma = mysqli_real_escape_string($conn, $_POST['TURMA']);
    $disciplina = mysqli_real_escape_string($conn, $_POST['DISCIPLINA']);
    //$periodo = mysqli_real_escape_string($conn,  $_POST['Periodo']);
    $tipo_prova = mysqli_real_escape_string($conn, $_POST['TIPOPROVA']);
    $data_prova = mysqli_real_escape_string($conn, $_POST['DATAPROVA']);
    //$coord = mysqli_real_escape_string($conn, $_POST['coord']);
    $professor = mysqli_real_escape_string($conn, $_POST['PROFESSOR']);
    $VAR = mysqli_real_escape_string($conn, $_POST['ID']);
    $agora = date('y-m-d');
    $status = mysqli_real_escape_string($conn, $_POST['STATUS']);

    $update = mysqli_query($conn, "UPDATE requisicao SET
                 nome_professor='$professor', tipo_prova='$tipo_prova', 
                 data_prova='$data_prova', status_requisicao='$status'
                 WHERE requisicao.id_requisicao = '$VAR'")
           
                                       
          or die('query failed');
          
         if($update){     
            mysqli_close($conn);
            ?>

            <script language="JavaScript">
                alert("Alterado com sucesso!");
            
                var paginaHome = 0;
            paginaHome2 = 0;  
            //var paginaHome = 0;
          
            </script>
                        
           <?php

        
         }
         else{
            $message = 'O registro não foi alterado!';
         }
}

?>
